document.getElementById('n2').textContent =
  'Reposición completada. ¡Gracias por vuestra paciencia!';
