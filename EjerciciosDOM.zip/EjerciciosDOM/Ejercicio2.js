let userName = prompt('Dime tu nombre', 'name');
if (userName == '') {
  alert('Bienvenido/a Persona Desconocida');
} else {
  alert('Bienvenido/a ' + userName);
}
