let num1 = prompt('Dime un numero');
let num2 = prompt('Dime otro numero');
alert('La suma de los dos numeros es: ' + (num1 + num2));
