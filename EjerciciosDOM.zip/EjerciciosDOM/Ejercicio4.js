let age = prompt('Que edad tienes?');
if (age >= 18) {
  alert('Mayor de edad');
} else {
  alert('Menor de edad');
}
