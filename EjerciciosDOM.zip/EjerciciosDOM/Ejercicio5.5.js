let nuevoElementoLista = document.createElement('li');
nuevoElementoLista.innerHTML = 'Tila <span class="precio">2.20</span>€';
ulLista.appendChild(nuevoElementoLista);
