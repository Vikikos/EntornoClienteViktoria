let casillasCheck = document.getElementsByName('alumnos');
for (let i = 0; i < casillasCheck.length; i++) {
  casillasCheck[i].setAttribute('checked', '');
}
