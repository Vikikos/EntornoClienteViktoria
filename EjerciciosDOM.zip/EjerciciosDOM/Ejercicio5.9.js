let elementosLista = document.getElementById('lista').querySelectorAll('li');
document.getElementById('log').innerHTML += elementosLista.length;
