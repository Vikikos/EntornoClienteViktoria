let sectionNoticias = document.getElementById('noticias');
sectionNoticias.removeChild(document.getElementById('n2'));
