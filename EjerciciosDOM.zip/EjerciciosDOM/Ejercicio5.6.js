let nuevoPrimerElemento = document.createElement('li');
let arrayLista = ulLista.getElementsByTagName('li');
arrayLista[0].innerHTML =
  'Producto destacado <span class="precio">9.99</span> €.';
