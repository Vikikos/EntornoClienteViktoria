//Declarar variables
var nombreVar = 'viki';
let nombreLet = 'viki';
const nombreConst = 'viki';

console.log('Variable var ' + nombreVar);
console.log('Variable let' + nombreLet);
console.log('Variable const' + nombreConst);

//reasignacion
nombreVar = 'viktoria';
nombreLet = 'viktoria';
nombreConst = 'viktoria';

console.log('Variable var ' + nombreVar);
console.log('Variable let'.nombreLet);
console.log('Variable const'.nombreConst);
