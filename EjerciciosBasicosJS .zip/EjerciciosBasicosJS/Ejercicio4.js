let nota = 7;
if (nota >= 9) {
  console.log('Sobresaliente');
  console.log('Felicidades');
} else if (nota <= 8 && nota >= 7) {
  console.log('Notable');
} else if (nota <= 6 && nota >= 5) {
  console.log('Aprobado');
} else {
  console.log('Suspenso');
}
