let contador = 0;
for (let i = 0; i < 5; i++) {
  contador++;
}

console.log(contador);
