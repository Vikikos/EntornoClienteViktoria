let sumaTodo = 0;
for (let i = 1; i <= 50; i++) {
  if (i % 4 == 0) {
    sumaTodo += i;
  }
}
console.log(sumaTodo);
